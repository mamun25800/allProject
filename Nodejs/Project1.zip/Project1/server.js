
import http from 'node:http'
import { serveStatic } from './utils/serveStatic.js'
import { handleGet,handlePost } from './handlers/routeHandler.js'


const __dirname=import.meta.dirname
const port=8000

const server  =http.createServer(async (req,res)=>{

    if(req.url==='/api'){
        if(req.method==='GET'){
            return await handleGet(res)
        }
        else if(req.method==='POST'){
            handlePost(req,res)
        }
    }

    else if(!req.url.startsWith('/api')){
      return await serveStatic(req,res,__dirname)
    }
})

server.listen(port,()=>console.log(`server runnig on port  ${port} `))
 