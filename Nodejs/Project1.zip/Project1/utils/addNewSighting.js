import { getData } from "./getData.js";
import path from 'node:path'
import fs from 'node:fs/promises'

export async function addNewSighting(newSighting){
    try{
        const sightings=await getData()
        sightings.push(newSighting)
        const pathJSON=path.join('data','data.json')

        await fs.writeFile(
            pathJSON,
            JSON.stringify(sightings,null,2),//pretty korar jonno null and 2 use 
            'utf8'
        )
    }catch(err){
        throw new Error(err)
    }
}