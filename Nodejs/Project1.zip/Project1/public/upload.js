const btn=document.querySelector('#submit')
const time=document.querySelector('#time')
const location=document.querySelector('#location')
const title=document.querySelector('#title')
const story = document.querySelector('#story')

btn.addEventListener('click',async(e)=>{
    e.preventDefault()

    try{
        const response=await fetch('/api',{
            method:'POST',
            headers:{
                'Content-Type':'application/json'
            },
            body:JSON.stringify({time:time.value,
                location:location.value,
                title:title.value,
                story:story.value
            })
        })
        const data=await response.json()
        console.log(data)
    }catch(err){
        console.log(err)
    }
})
