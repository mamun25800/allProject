import { getData } from "../utils/getData.js";
import { sendResponse } from "../utils/sendResponse.js";
import { parseJSONBody } from "../utils/parseJSONBody.js";
import { addNewSighting } from "../utils/addNewSighting.js";

export async function handleGet(res) {
    const data=  await getData()
    const content=JSON.stringify(data)
    sendResponse(res,200,'application/json',content)
}

export async function handlePost(req,res){
    try{
        const parsedBody= await parseJSONBody(req)
        await addNewSighting(parsedBody)
        sendResponse(res,200,'applicaton/json',JSON.stringify(parsedBody))
    }catch(err){
        throw new Error(`error occur ${err}`)
    }
}